In order to run this project you must run:

pip install -r ./requirements.txt

which will install the necessary packages. From there you can run the python file using the interperter and it should run fine.
This python file will generate both the svg used in the report as well as the interactible visualization.

The data source is in the bibliography of the report but I'll include a link here just in case.

https://www.kaggle.com/datasets/bhadramohit/customer-shopping-latest-trends-dataset/data
